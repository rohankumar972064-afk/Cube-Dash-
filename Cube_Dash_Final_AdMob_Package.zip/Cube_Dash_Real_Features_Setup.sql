-- CUBE DASH: secure server-side bonus / rewarded-ad / withdrawal helpers
-- Run this in Supabase SQL Editor AFTER your existing Cube Dash tables are present.
-- Never put Supabase service_role or payout provider secrets in the HTML.

create unique index if not exists bonus_claims_user_date_uq
  on public.bonus_claims(user_id, claim_date);

create table if not exists public.reward_ad_claims (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  coins integer not null,
  created_at timestamptz not null default now()
);

alter table public.reward_ad_claims enable row level security;

drop policy if exists reward_ad_claims_select_own on public.reward_ad_claims;
create policy reward_ad_claims_select_own on public.reward_ad_claims
  for select to authenticated using (user_id = auth.uid());

create or replace function public.claim_daily_bonus()
returns table(day_number integer, coins integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  today date := current_date;
  already boolean;
  claimed_count integer;
  d integer;
  reward integer;
begin
  if uid is null then raise exception 'LOGIN_REQUIRED'; end if;

  select exists(
    select 1 from public.bonus_claims
    where user_id = uid and claim_date = today
  ) into already;
  if already then raise exception 'BONUS_ALREADY_CLAIMED'; end if;

  select count(*)::integer into claimed_count
  from public.bonus_claims where user_id = uid;
  d := (claimed_count % 7) + 1;

  select wb.coins into reward
  from public.weekly_bonus wb
  where wb.day_number = d;

  if reward is null then
    reward := case d when 1 then 20 when 2 then 30 when 3 then 40 when 4 then 50 when 5 then 60 when 6 then 80 else 100 end;
  end if;

  update public.profiles
    set coins = coalesce(coins,0) + reward
  where id = uid;

  if not found then raise exception 'PROFILE_NOT_FOUND'; end if;

  insert into public.bonus_claims(user_id, day_number, coins, claim_date)
  values(uid, d, reward, today);

  return query select d, reward;
exception
  when unique_violation then
    raise exception 'BONUS_ALREADY_CLAIMED';
end;
$$;

revoke all on function public.claim_daily_bonus() from public;
grant execute on function public.claim_daily_bonus() to authenticated;

create or replace function public.claim_reward_ad()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  reward integer;
begin
  if uid is null then raise exception 'LOGIN_REQUIRED'; end if;

  select coalesce(reward_ad_coins,50) into reward
  from public.app_settings where id=1;
  reward := greatest(coalesce(reward,50),0);

  update public.profiles
    set coins = coalesce(coins,0) + reward
  where id=uid;
  if not found then raise exception 'PROFILE_NOT_FOUND'; end if;

  insert into public.reward_ad_claims(user_id,coins) values(uid,reward);
  return jsonb_build_object('coins',reward);
end;
$$;

revoke all on function public.claim_reward_ad() from public;
grant execute on function public.claim_reward_ad() to authenticated;

create or replace function public.create_withdrawal(
  p_amount numeric,
  p_method text,
  p_account_name text,
  p_upi_id text default null,
  p_bank_account text default null,
  p_ifsc_code text default null,
  p_bank_name text default null
)
returns public.withdrawals
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  cpr numeric;
  min_w numeric;
  max_w numeric;
  daily_w numeric;
  need numeric;
  today_total numeric;
  w public.withdrawals;
begin
  if uid is null then raise exception 'LOGIN_REQUIRED'; end if;
  if p_amount <= 0 then raise exception 'INVALID_AMOUNT'; end if;

  select coalesce(coins_per_rupee,200),coalesce(minimum_withdrawal,100),
         coalesce(maximum_withdrawal,1000),coalesce(daily_withdrawal_limit,5000)
  into cpr,min_w,max_w,daily_w
  from public.app_settings where id=1;

  if p_amount < min_w or p_amount > max_w then raise exception 'AMOUNT_OUT_OF_RANGE'; end if;
  need := p_amount * cpr;

  select coalesce(sum(amount),0) into today_total
  from public.withdrawals
  where user_id=uid and created_at >= date_trunc('day',now())
    and status in ('Pending','Approved');
  if today_total + p_amount > daily_w then raise exception 'DAILY_LIMIT_EXCEEDED'; end if;

  update public.profiles
    set coins=coalesce(coins,0)-need
  where id=uid and coalesce(coins,0) >= need;
  if not found then raise exception 'INSUFFICIENT_COINS'; end if;

  insert into public.withdrawals(
    amount,coins_used,status,method,account_name,upi_id,bank_account,ifsc_code,bank_name,user_id
  ) values(
    p_amount,need,'Pending',p_method,p_account_name,p_upi_id,p_bank_account,p_ifsc_code,p_bank_name,uid
  ) returning * into w;

  return w;
end;
$$;

revoke all on function public.create_withdrawal(numeric,text,text,text,text,text,text) from public;
grant execute on function public.create_withdrawal(numeric,text,text,text,text,text,text) to authenticated;

create or replace function public.admin_set_withdrawal_status(
  p_withdrawal_id uuid,
  p_status text
)
returns public.withdrawals
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  is_admin boolean;
  w public.withdrawals;
begin
  if uid is null then raise exception 'LOGIN_REQUIRED'; end if;
  select coalesce(is_admin,false) into is_admin from public.profiles where id=uid;
  if not is_admin then raise exception 'ADMIN_REQUIRED'; end if;
  if p_status not in ('Approved','Rejected') then raise exception 'INVALID_STATUS'; end if;

  select * into w from public.withdrawals where id=p_withdrawal_id for update;
  if not found then raise exception 'WITHDRAWAL_NOT_FOUND'; end if;
  if w.status <> 'Pending' then raise exception 'WITHDRAWAL_ALREADY_PROCESSED'; end if;

  if p_status='Rejected' then
    update public.profiles set coins=coalesce(coins,0)+coalesce(w.coins_used,0) where id=w.user_id;
  end if;

  update public.withdrawals set status=p_status where id=p_withdrawal_id returning * into w;
  return w;
end;
$$;

revoke all on function public.admin_set_withdrawal_status(uuid,text) from public;
grant execute on function public.admin_set_withdrawal_status(uuid,text) to authenticated;

-- Recommended RLS checks. Keep your existing policies if they are stricter.
-- The RPCs above are SECURITY DEFINER, so users do not need direct INSERT/UPDATE access
-- for bonus claims or withdrawals.
