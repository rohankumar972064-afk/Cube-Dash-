package com.cubedash.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private String pendingType = "reward";
    private boolean rewardEarned = false;

    // Google test rewarded ad unit. Replace with your real rewarded unit before release.
    private static final String TEST_REWARDED_AD = "ca-app-pub-3940256099942544/5224354917";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileAds.initialize(this, status -> loadRewardedAd());

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, TEST_REWARDED_AD, request, new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull RewardedAd ad) {
                rewardedAd = ad;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError error) {
                rewardedAd = null;
            }
        });
    }

    private void showRewarded(final String type) {
        pendingType = type == null ? "reward" : type;
        rewardEarned = false;

        if (rewardedAd == null) {
            notifyJs(false);
            loadRewardedAd();
            return;
        }

        RewardedAd ad = rewardedAd;
        rewardedAd = null;

        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                notifyJs(rewardEarned);
                loadRewardedAd();
            }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                notifyJs(false);
                loadRewardedAd();
            }
        });

        ad.show(this, rewardItem -> rewardEarned = true);
    }

    private void notifyJs(final boolean completed) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript(
                "window.cubeAdFinished && window.cubeAdFinished(" + completed + ");", null));
    }

    private class AdBridge {
        @JavascriptInterface
        public void showAd(String type, String ignoredUnit) {
            runOnUiThread(() -> showRewarded(type));
        }
    }
}
